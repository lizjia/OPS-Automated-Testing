﻿# Setting up Pycharm

Python contains packages using a "Virtual Environment", shortened to **venv**. Because of the nature of these packages, no part of a **venv** should ever be uploaded to github. Instead, we upload only code we have written, and store a file called **"requirements.txt"** which holds a list of packages every person must install on their computer. 

 This makes setup very simple. The main project directory in this case is **Chrome Tests**. Once we open that in Pycharm, we simply run this command in the **terminal in Pycharm**.
```
pip install -r requirements.txt
```

This reads all of the required packages from the text file and installs them locally. 

Any time you **install a new package** that is necessary to every person using the code, simply update the requirements text file like so:
```
pip freeze > requirements.txt
```


# Running Tests

You will have to run tests from the **terminal** in Pycharm. For example, simply running:
```
pytest
```

  will run the available test cases according to pytest's detection of tests in the current directory. 

As a habit, when running tests make sure to specify what you would like to see and run with helpful markers like:
```
pytest -v
# More info displayed
pytest -q
# Less info displayed
pytest -x
# Exit after first test failure
pytest -h
# See help menu for pytest
^ Or any combination of the above ^
```

The login tests need to be run in the **LoginTests** directory. This means your terminal chould start with this:
```
(venv) ...installation location...\Chrome Tests\LoginTests>
```
Certain arguments are important to the running of the tests
```
-n=x                --> This argument allows "x" number of tests to run in parallel
--users="exmpluser" --> This argument is used to add a username for GO Secure
                        **Right now it will use "Password123!" as the password for any account you add

```
The number of times you use the argument *--users* will determine the number of tests, while the number you provide to *-n* will be the number of browser windows allowed to be open at once. 

If *-n* does not match the number of tests, the results **will not be accurate** as they will be conducted one after another instead of altogether.

Here is how you might run the test:
```
pytest --users="user1@gmail.com" --users="user2@gmail.com" test_logins.py -v -n=2
```

# Making Code Changes

In order for our code to be **clean** and our history to be **readable**, we want to try our best to adhere to some **GitFlow Guidelines**:
- Never work directly on **main**
- Always create a new branch for any **changes** (This includes **hotfixes** and expecially **features**)
- Create **sub-branches** for large features (main -> feature1 -> task_in_feature1)
- Always make a **pull request** when merging branches and get them **reviewed**

Any time you make a change to the repository, it should look like this:
``Create Branch -> Make changes -> Commit changes -> Make Pull Request -> Merge changes`` 

and the branch you create  above should **never** be directly connected to main.

Lastly, if you have any instructions that need to be followed, **add them to the README files**. These are not set in stone and can change often, so anything that is required to read **before or while** using your code should be put in here.

this is a code change :P