from selenium import webdriver

ENVS = {
    "UAT": "https://www.iamu.security.gov.on.ca/goID/access/index.jsp?authn_try_count=0&contextType=external&username=string&contextValue=%2Foam&password=sercure_string&challenge_url=https%3A%2F%2Fwww.iamu.security.gov.on.ca%2FgoID%2Faccess%2Findex.jsp&ssoCookie=Secure%3Bhttponly&request_id=-3888376288493074198&OAM_REQ=&locale=en_US&resource_url=https%253A%252F%252Fwww.iamu.security.gov.on.ca%252FgoID%252Fprofile%252Findex.xhtml",
    "SIT": "https://sit.prov.security.gov.on.ca/identity"
}

MAX_TIME = 10000


def test_login_response_time(args):
    user = args[0]
    pw = args[1]
    address = ENVS[args[2]]
    results_file = "Login UAT Test Results/Login Test Results.txt"

    options = webdriver.ChromeOptions()
    options.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome("../../WebDriver/bin/chromedriver", options=options)
    results = open(results_file, "a")

    driver.get(address)
    username = driver.find_element_by_id("username")
    password = driver.find_element_by_id("password")
    username.send_keys(user)
    password.send_keys(pw)

    # Time spent after user completes unloading prev page
    navigation_start = driver.execute_script("return window.performance.timing.navigationStart")
    # Time first piece of data is received from server
    response_start = driver.execute_script("return window.performance.timing.responseStart")
    # Time the page load is complete
    dom_complete = driver.execute_script("return window.performance.timing.domComplete")

    ''' Calculate the performance'''
    backend_performance_calc = response_start - navigation_start
    frontend_performance_calc = dom_complete - response_start
    total_performance_calc = backend_performance_calc + frontend_performance_calc

    results.write(user + "," + str(total_performance_calc) + "\n")

    results.close()
    driver.close()

    assert total_performance_calc < MAX_TIME
