import os

# shell command
def run_pytest (args, test_file):
    # cmd = 'pytest --users="logins_short.txt" -n=2 -v test_logins.py'
    cmd = 'pytest'
    for arg in args:
        cmd = cmd + " " + arg
    cmd = cmd + " " + test_file
    print(cmd)
    os.system(cmd)


