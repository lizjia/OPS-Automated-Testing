import matplotlib.pyplot as plt

def create_bar_graph(d1):
    xb = d1.keys()
    yb = d1.values()

    plt.title('Login Test Result Summary')
    plt.ylabel('Time (ms)')
    plt.bar(xb, yb)
    plt.savefig('bar_graph.png', dpi=300)
    plt.close()

def create_scatter_plot(d2):
    xs = d2.keys()
    ys = d2.values()

    plt.title('Login Test Times')
    plt.xticks(rotation=75)
    plt.ylabel('Time (ms)')
    plt.xlabel('Account')
    plt.scatter(xs, ys)
    plt.savefig('scatter_plot.png', dpi=300, bbox_inches='tight')
    plt.close()

