import pytest

from datetime import datetime
from selenium import webdriver


def pytest_addoption(parser):
    parser.addoption(
        "--users",
        action="store",
        default=None,
        help="Name of a text file containing a list of comma separated login info. Will ignore badly formatted lines",

    )
    parser.addoption(
        "--env",
        action="store",
        default="UAT",
        help="Environment to run the tests on"
    )


def pytest_generate_tests(metafunc):
    if "args" in metafunc.fixturenames:
        users = metafunc.config.getoption("--users")
        env = metafunc.config.getoption("--env")
        args_list = []
        if users:
            with open("Login UAT Test Results/Login Test Results.txt", "r+") as res:
                res.truncate()
            users_file = open(users, "r")
            for line in users_file:
                sep = line.find(",")
                if sep != -1:
                    args_list.append((line[0:sep].strip(), line[sep+1:].strip(), env))
            users_file.close()

        metafunc.parametrize("args", args_list)
