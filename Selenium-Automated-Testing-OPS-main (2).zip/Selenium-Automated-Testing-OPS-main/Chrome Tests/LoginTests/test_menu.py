import PySimpleGUI as sg
import statistics as stat
import test_logins
from Helper import results_graph, command, image_processing


# error checking received string with login information
def error_check(user_entry):
    if user_entry == "":
        return False
    elif user_entry[-4:] != ".txt":
        return False
    return True


def get_test_data(file):
    results = open(file, "r")
    data = {}
    for line in results:
        split = line.find(",")
        data[line[:split].strip()] = int(line[split + 1:].strip())
    return data


def get_data_summary(data):
    vals = list(data.values())
    summary = {
        "shortest": min(vals),
        "longest": max(vals),
        "average": stat.mean(vals),
        "median": stat.median(vals)
    }
    return summary


# All the stuff inside your window.
layout = [
    [sg.Text('Enter info for Login Tests')],
    [sg.Text('Account Info'), sg.Input(), sg.FileBrowse()],
    [sg.Text('Environment'), sg.DropDown(list(test_logins.ENVS.keys()), default_value="UAT")],
    [sg.Button('Ok'), sg.Button('Cancel')]
]

# Create the Window
window = sg.Window('Login Tests', layout)
# Event Loop to process "events" and get the "values" of the inputs
while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Cancel':  # if user closes window or clicks cancel
        break
    elif event == 'Ok' and values[0] != '':
        accounts_file = values[0]
        env = values[1]
        if error_check(accounts_file):
            num_tests = sum(1 for line in open(accounts_file))
            test_args = [
                "-n=\"" + str(num_tests) + "\"",
                "--users=\"" + accounts_file + "\"",
                "--env=\"" + env + "\"",
                "-v"
            ]
            command.run_pytest(test_args, "test_logins.py")

            all_data = get_test_data("Login UAT Test Results/Login Test Results.txt")
            summary_data = get_data_summary(all_data)
            results_graph.create_scatter_plot(all_data)
            results_graph.create_bar_graph(summary_data)

            results_layout = [
                [
                    sg.Image(data=image_processing.convert_to_bytes("./bar_graph.png", resize=(450, 450))),
                    sg.Image(data=image_processing.convert_to_bytes("./scatter_plot.png", resize=(450, 450)))],
                [sg.Button('Run Another Test'), sg.Button('End Tests')]
            ]
            results_window = sg.Window('Login Test Results', results_layout)
            results_event, results_values = results_window.read()
            print(results_event)
            if results_event == 'End Tests':
                break
            results_window.close()
        else:
            sg.popup('Please provide a text file\n  Every line should be in this format:\n  email@email.com, password')

window.close()
