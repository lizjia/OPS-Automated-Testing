﻿# README

The objective of having this repository will be to **organize** code and facilitate **good coding practices**.


# Files

Currently the folder **"Chrome Tests"** holds the python files and will be the source of your Pycharm project. Expect the name to change in the future.


